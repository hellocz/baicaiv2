#2.0.1

###Features

* Add entry point for CommonJS require. Now Notyf can be imported as `var Notyf = require('notyf')`

#2.0.0

###Features

* Add support for AMD & CommonJS modules.

###Refactor

* Change CSS classes to adopt a better and cleaner BEM methodology.

###Bug Fixes

* The alert notification no longer interferes with the Bootstrap's `alert` class. 